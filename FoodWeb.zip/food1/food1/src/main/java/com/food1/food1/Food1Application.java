package com.food1.food1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.food1.food1")
public class Food1Application {

	public static void main(String[] args) {
		SpringApplication.run(Food1Application.class, args);
	}

}
