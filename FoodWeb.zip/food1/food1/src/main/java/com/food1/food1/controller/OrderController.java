package com.food1.food1.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.food1.food1.model.Order;
import com.food1.food1.model.OrderRequest;
import com.food1.food1.model.User;
import com.food1.food1.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    @PostMapping("/createOrders")
    public ResponseEntity<Map<String, String>> createOrders(@RequestBody List<OrderRequest> orderRequests) {
        try {
            for (OrderRequest orderRequest : orderRequests) {
                User user = orderRequest.getUser(); // Get the user from the request

                Order order = new Order(orderRequest.getOrderitems());
                order.setUser(user); // Set the user for the order

                double totalAmount = order.calculateTotalAmount();
                order.setTotalAmount(totalAmount);

                order.setOrderId(order.generateOrderItemId());
                order.setOrderDate(order.generateOrderDate());

                orderService.saveOrder(order);
            }

            return ResponseEntity.ok(Collections.singletonMap("message", "Orders created successfully."));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonMap("error", "Failed to create orders. Please try again later."));
        }
    }

}
