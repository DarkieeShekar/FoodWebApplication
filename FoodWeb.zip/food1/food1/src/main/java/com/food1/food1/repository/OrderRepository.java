package com.food1.food1.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.food1.food1.model.Order;

public interface OrderRepository extends MongoRepository<Order, String> {

 
}