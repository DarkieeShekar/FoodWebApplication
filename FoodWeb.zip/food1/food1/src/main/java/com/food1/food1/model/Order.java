package com.food1.food1.model;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "orders")
public class Order {
    private String orderId;
    private String orderDate;
    private User user;
    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	private List<OrderItem> orderitems;
    private double totalAmount;
    private String status;
    
    public Order(List<OrderItem> orderitems) {
        this.orderitems = orderitems;
        this.totalAmount = calculateTotalAmount(); // Calculate the total amount based on items

        this.orderId = generateOrderItemId();
        this.orderDate = generateOrderDate();
        this.status = "Pending";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

 // Helper methods for generating IDs and dates
    public String generateOrderItemId() {
        return UUID.randomUUID().toString(); // Generates a unique UUID
    }

    public String generateOrderDate() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return now.format(formatter); // Formats the current date and time
    }

    public String generateUserId() {
        return UUID.randomUUID().toString(); // Generates a unique UUID
    }

	public String getOrderitemId() {
		return orderId;
	}
	public void setOrderitemId(String orderitemId) {
		this.orderId = orderitemId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}



	public List<OrderItem> getOrderitems() {
		return orderitems;
	}
	public void setOrderitems(List<OrderItem> orderitems) {
		this.orderitems = orderitems;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Order(String orderId, String orderDate, User user, List<OrderItem> orderitems, double totalAmount,
			String status) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.user = user;
		this.orderitems = orderitems;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

    // ... other methods ...

	 public double calculateTotalAmount() {
	        double total = 0;
	        for (OrderItem item : orderitems) {
	            total += item.getQuantity() * item.getPrice();
	        }
	        return total;
	    }
}
