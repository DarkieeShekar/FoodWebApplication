package com.food1.food1.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food1.food1.model.Order;
import com.food1.food1.model.OrderItem;
import com.food1.food1.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    public void saveOrder(Order order) {
        // Calculate total amount and set it in the order
        double totalAmount = calculateTotalAmount(order);
        order.setTotalAmount(totalAmount);

        // Save the order to the repository
        orderRepository.save(order);
    }

    @Override
    public double calculateTotalAmount(Order order) {
        double total = 0;
        for (OrderItem item : order.getOrderitems()) {
            total += item.getQuantity() * item.getPrice();
        }
        return total;
    }
}
