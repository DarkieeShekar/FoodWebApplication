package com.food1.food1.model;

public class User {
    private String username;

    public User() {
        // Default constructor
    }

    public User(String username) {
        this.username = username;
    }

    // Getter and setter for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
