package com.food1.food1.service;

import com.food1.food1.model.Order;

public interface OrderService {
    void saveOrder(Order order);
    double calculateTotalAmount(Order order);
}
