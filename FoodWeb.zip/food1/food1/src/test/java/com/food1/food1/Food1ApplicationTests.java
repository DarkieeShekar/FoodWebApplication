package com.food1.food1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Food1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
